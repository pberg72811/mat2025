#define TYPE uint16_t
#define BWL(x) x ## w
#include "pci/readx.c"
