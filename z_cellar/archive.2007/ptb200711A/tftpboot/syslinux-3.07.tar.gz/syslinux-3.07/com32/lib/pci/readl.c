#define TYPE uint32_t
#define BWL(x) x ## l
#include "pci/readx.c"
