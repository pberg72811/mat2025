#define TYPE uint8_t
#define BWL(x) x ## b
#include "pci/writex.c"
