#define TYPE uint16_t
#define BWL(x) x ## w
#include "pci/writex.c"
