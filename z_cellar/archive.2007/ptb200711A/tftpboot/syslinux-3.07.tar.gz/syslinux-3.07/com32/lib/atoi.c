#define TYPE int
#define NAME atoi
#include "atox.c"
