#define VERSION "3.07"
#define VER_MAJOR 3
#define VER_MINOR 7
