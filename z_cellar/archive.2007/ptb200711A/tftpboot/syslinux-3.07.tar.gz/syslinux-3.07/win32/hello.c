/*
 * Test program for C compiler; if this doesn't compile, the
 * C compiler is seriously broken.
 */

#include <stdlib.h>
#include <stdio.h>

int main(void)
{
  printf("Hello, World!\n");
  return 0;
}
